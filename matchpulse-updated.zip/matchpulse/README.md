# MatchPulse

Never miss a match. A dark-mode-first PWA for following clubs, national
teams, and competitions — with match reminders that go exactly where you
want them.

## What's in this v1

- **Home** — live countdown to your next followed match, today's fixtures, upcoming fixtures, recent results
- **Favorites** — follow clubs/national teams (seed list included, easy to extend)
- **Match details** — competition, kickoff (converted to your local time), venue, status
- **Calendar** — grouped upcoming fixtures + `.ics` export
- **Notifications** — pick exactly which reminders you want (1 week down to kickoff) and which match events matter to you
- **Installable PWA** — offline caching, add-to-homescreen, works one-handed

## Data source

Real fixtures come from **[football-data.org](https://www.football-data.org)**,
which is free forever for these competitions: Champions League, Premier
League, La Liga, Bundesliga, Serie A, Ligue 1, Eredivisie, Primeira Liga,
Championship, Brazilian Serie A, World Cup, and the Euros.

Because GitHub Pages only serves static files (no server to hide an API key
or handle CORS), the app **doesn't call the API from the browser**. Instead:

1. A GitHub Action (`update-data.yml`) runs on a schedule, calls
   football-data.org from GitHub's servers, and writes the results to
   `public/data/*.json`.
2. The app just fetches those static JSON files — fast, no key exposed, no
   CORS issues, works on the free Pages tier.

Sample data is already checked in under `public/data/` so the app works out
of the box before you've set anything up.

## Setup

```bash
npm install
npm run dev
```

### 1. Get a free API key

Register at https://www.football-data.org/client/register — the key
arrives by email within a few minutes.

### 2. Point the app at your repo

In `vite.config.ts`, set `BASE_PATH` to match your GitHub Pages URL:
- Project page (`username.github.io/matchpulse`) → `/matchpulse/`
- User/org page (`username.github.io`) → `/`

### 3. Pull real data locally (optional)

```bash
FOOTBALL_DATA_TOKEN=your_key_here npm run fetch-data
```

### 4. Deploy

1. Push this repo to GitHub.
2. In **Settings → Secrets and variables → Actions**, add a secret named
   `FOOTBALL_DATA_TOKEN` with your key.
3. In **Settings → Pages**, set Source to **GitHub Actions**.
4. Push to `main` — `deploy.yml` builds and publishes automatically.
   `update-data.yml` then refreshes fixtures every 30 minutes and
   auto-triggers a redeploy.

Your app will be live at `https://<username>.github.io/matchpulse/`.

## Notification limitations (please read)

Static hosting means there's no server to hold a connection or send Web
Push while your phone's browser is closed. This v1 schedules reminders with
the in-browser Notification API, re-synced every time the app is opened or
foregrounded — great for an installed/pinned PWA that you open regularly,
but it won't wake up a fully-closed browser on its own.

**Going further:** to get true background push (app fully closed,
still notified), add a small serverless function (Cloudflare Workers,
Vercel, or Firebase Cloud Messaging as listed in the original spec) that
holds subscriptions and sends Web Push via VAPID keys. The scheduling logic
in `src/lib/notifications.ts` is written so you can swap the "fire"
mechanism without touching the rest of the app.

## Extending

- **More teams/competitions**: edit `COMPETITIONS` in `scripts/fetch-data.mjs`
  and `SUGGESTED` in `src/pages/Favorites.tsx`
- **Search**: wire a `/data/teams.json` index (generate it in the fetch
  script) and build a simple filter page
- **Live match detail** (H2H, lineups, xG): the free tier doesn't include
  these — see the README note in `MatchDetails.tsx` for upgrade paths
- **Deeper stats/odds**: consider API-Football or a paid tier once you
  outgrow football-data.org's free plan

## Tech stack

React · Vite · TypeScript · Tailwind CSS · React Router · vite-plugin-pwa ·
idb-keyval (IndexedDB) · GitHub Actions · GitHub Pages
