/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#0A0D16',
          900: '#0D1220',
          800: '#141B2E',
          700: '#1B2440',
          600: '#2A3558'
        },
        floodlight: {
          400: '#FFD766',
          500: '#F2B705',
          600: '#C99604'
        },
        pulse: {
          400: '#7C8CF8',
          500: '#5B6EF5',
          600: '#4453D6'
        },
        mist: {
          300: '#C7CCDC',
          400: '#8B92A8',
          500: '#666E88'
        }
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace']
      },
      boxShadow: {
        glow: '0 0 40px -8px rgba(242, 183, 5, 0.35)',
        card: '0 8px 24px -12px rgba(0,0,0,0.5)'
      },
      backgroundImage: {
        stadium: 'radial-gradient(circle at 50% 0%, rgba(242,183,5,0.10), transparent 60%)'
      }
    }
  },
  plugins: []
}
