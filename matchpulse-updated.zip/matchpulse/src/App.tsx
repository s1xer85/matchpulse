import { Routes, Route } from 'react-router-dom'
import BottomNav from './components/BottomNav'
import Home from './pages/Home'
import Favorites from './pages/Favorites'
import Calendar from './pages/Calendar'
import NotificationsPage from './pages/Notifications'
import Settings from './pages/Settings'
import MatchDetails from './pages/MatchDetails'

export default function App() {
  return (
    <div className="min-h-full max-w-lg mx-auto relative">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/favorites" element={<Favorites />} />
        <Route path="/calendar" element={<Calendar />} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/match/:id" element={<MatchDetails />} />
      </Routes>
      <BottomNav />
    </div>
  )
}
