import { useEffect, useState } from 'react'
import Header from '../components/Header'
import { getNotificationPrefs, setNotificationPrefs, getFavorites } from '../lib/db'
import { requestNotificationPermission, scheduleReminders } from '../lib/notifications'
import { getUpcomingMatches } from '../lib/api'
import { REMINDER_LABELS, type NotificationPrefs, type ReminderOffset } from '../types'

const OFFSET_ORDER: ReminderOffset[] = [
  'week_1', 'day_3', 'day_1', 'hour_12', 'hour_6', 'hour_3', 'hour_1', 'min_30', 'min_15', 'min_5', 'kickoff'
]

export default function NotificationsPage() {
  const [prefs, setPrefs] = useState<NotificationPrefs | null>(null)
  const [permission, setPermission] = useState<NotificationPermission>('default')
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    getNotificationPrefs().then(setPrefs)
    if ('Notification' in window) setPermission(Notification.permission)
  }, [])

  async function handleEnable() {
    const result = await requestNotificationPermission()
    setPermission(result)
    if (result === 'granted') await resync()
  }

  async function resync() {
    if (!prefs) return
    const [matches, favorites] = await Promise.all([getUpcomingMatches(), getFavorites()])
    await scheduleReminders(matches, new Set(favorites.map((f) => f.id)), prefs.reminders)
  }

  function toggleOffset(offset: ReminderOffset) {
    if (!prefs) return
    const has = prefs.reminders.includes(offset)
    const reminders = has ? prefs.reminders.filter((o) => o !== offset) : [...prefs.reminders, offset]
    void save({ ...prefs, reminders })
  }

  function toggleEvent(key: keyof NotificationPrefs['events']) {
    if (!prefs) return
    void save({ ...prefs, events: { ...prefs.events, [key]: !prefs.events[key] } })
  }

  async function save(next: NotificationPrefs) {
    setPrefs(next)
    await setNotificationPrefs(next)
    setSaved(true)
    setTimeout(() => setSaved(false), 1200)
    if (permission === 'granted') await scheduleFor(next)
  }

  async function scheduleFor(next: NotificationPrefs) {
    const [matches, favorites] = await Promise.all([getUpcomingMatches(), getFavorites()])
    await scheduleReminders(matches, new Set(favorites.map((f) => f.id)), next.reminders)
  }

  if (!prefs) return null

  return (
    <div className="pb-24">
      <Header title="Notifications" subtitle="Only get pinged for what matters to you" />

      <div className="px-5 mt-2 space-y-6">
        {permission !== 'granted' && (
          <button
            onClick={handleEnable}
            className="w-full rounded-2xl bg-floodlight-500 text-ink-900 font-semibold py-3 shadow-glow active:scale-[0.98] transition-transform"
          >
            Enable notifications
          </button>
        )}
        {permission === 'denied' && (
          <p className="text-xs text-mist-500 text-center">
            Notifications are blocked in your browser settings — enable them there to receive reminders.
          </p>
        )}

        <section>
          <h2 className="font-display text-sm font-semibold text-mist-300 uppercase tracking-wide mb-3">
            Match reminders
          </h2>
          <div className="rounded-2xl bg-ink-800/60 border border-ink-600/40 divide-y divide-ink-600/40">
            {OFFSET_ORDER.map((offset) => (
              <ToggleRow
                key={offset}
                label={REMINDER_LABELS[offset]}
                checked={prefs.reminders.includes(offset)}
                onChange={() => toggleOffset(offset)}
              />
            ))}
          </div>
        </section>

        <section>
          <h2 className="font-display text-sm font-semibold text-mist-300 uppercase tracking-wide mb-3">
            Match events
          </h2>
          <div className="rounded-2xl bg-ink-800/60 border border-ink-600/40 divide-y divide-ink-600/40">
            <ToggleRow label="Goals" checked={prefs.events.goals} onChange={() => toggleEvent('goals')} />
            <ToggleRow label="Half time" checked={prefs.events.halfTime} onChange={() => toggleEvent('halfTime')} />
            <ToggleRow label="Full time" checked={prefs.events.fullTime} onChange={() => toggleEvent('fullTime')} />
            <ToggleRow label="Red cards" checked={prefs.events.redCard} onChange={() => toggleEvent('redCard')} />
            <ToggleRow label="Lineups released" checked={prefs.events.lineupReleased} onChange={() => toggleEvent('lineupReleased')} />
          </div>
          <p className="text-xs text-mist-500 mt-2">
            Event alerts fire while the app is open in this v1 build. Background delivery
            needs a small push server — see README.
          </p>
        </section>

        {saved && <p className="text-center text-xs text-floodlight-400">Saved</p>}
      </div>
    </div>
  )
}

function ToggleRow({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return (
    <label className="flex items-center justify-between px-4 py-3 text-sm cursor-pointer">
      <span className="text-white">{label}</span>
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        className="w-5 h-5 rounded accent-floodlight-500"
      />
    </label>
  )
}
