import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getMatchById } from '../lib/api'
import type { Match } from '../types'

export default function MatchDetails() {
  const { id } = useParams()
  const [match, setMatch] = useState<Match | null | undefined>(undefined)

  useEffect(() => {
    if (!id) return
    getMatchById(Number(id)).then((m) => setMatch(m ?? null))
  }, [id])

  if (match === undefined) return <div className="p-5 text-mist-500">Loading…</div>
  if (match === null) {
    return (
      <div className="p-5">
        <p className="text-mist-400">Match not found.</p>
        <Link to="/" className="text-floodlight-400 text-sm underline">Back to Home</Link>
      </div>
    )
  }

  const kickoff = new Date(match.utcDate)

  return (
    <div className="pb-24">
      <div className="px-5 pt-6 pb-4">
        <Link to="/" className="text-mist-500 text-sm">&larr; Back</Link>
      </div>

      <div className="px-5">
        <p className="text-xs uppercase tracking-widest text-floodlight-500 font-semibold mb-4 text-center">
          {match.competition.name}
        </p>

        <div className="flex items-center justify-center gap-6 mb-6">
          <TeamBlock name={match.homeTeam.name} crest={match.homeTeam.crest} score={match.score.home} />
          <span className="font-display text-mist-500">vs</span>
          <TeamBlock name={match.awayTeam.name} crest={match.awayTeam.crest} score={match.score.away} />
        </div>

        <div className="rounded-2xl bg-ink-800/60 border border-ink-600/40 divide-y divide-ink-600/40">
          <Row label="Date" value={kickoff.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })} />
          <Row label="Kickoff (local)" value={kickoff.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })} />
          <Row label="Venue" value={match.venue ?? 'TBC'} />
          <Row label="Status" value={match.status.replace('_', ' ')} />
        </div>

        <p className="text-xs text-mist-500 text-center mt-4">
          Deeper stats — H2H, form, lineups, xG — populate once you upgrade the data
          source (see README "Going further").
        </p>
      </div>
    </div>
  )
}

function TeamBlock({ name, crest, score }: { name: string; crest: string; score: number | null }) {
  return (
    <div className="flex flex-col items-center gap-2 w-24">
      <img src={crest} alt="" className="w-14 h-14 rounded-full bg-ink-700 object-contain" loading="lazy" />
      <span className="text-sm font-medium text-white text-center">{name}</span>
      {score !== null && <span className="font-mono text-xl font-semibold text-floodlight-400">{score}</span>}
    </div>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between px-4 py-3 text-sm">
      <span className="text-mist-500">{label}</span>
      <span className="text-white font-medium">{value}</span>
    </div>
  )
}
