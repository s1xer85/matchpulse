import Header from '../components/Header'

export default function Settings() {
  return (
    <div className="pb-24">
      <Header title="Settings" />
      <div className="px-5 mt-2 space-y-6">
        <section className="rounded-2xl bg-ink-800/60 border border-ink-600/40 divide-y divide-ink-600/40">
          <InfoRow label="Theme" value="Dark (system default)" />
          <InfoRow label="Timezone" value={Intl.DateTimeFormat().resolvedOptions().timeZone} />
          <InfoRow label="Data source" value="football-data.org (free tier)" />
        </section>

        <p className="text-xs text-mist-500 leading-relaxed px-1">
          MatchPulse stores your favorites and preferences only on this device
          (IndexedDB) — nothing is sent to a server. Uninstalling the app or
          clearing site data removes them.
        </p>
      </div>
    </div>
  )
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between px-4 py-3 text-sm">
      <span className="text-mist-500">{label}</span>
      <span className="text-white font-medium">{value}</span>
    </div>
  )
}
