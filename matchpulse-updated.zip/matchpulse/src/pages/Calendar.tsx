import { useEffect, useState } from 'react'
import Header from '../components/Header'
import MatchCard from '../components/MatchCard'
import { getUpcomingMatches } from '../lib/api'
import { getFavorites } from '../lib/db'
import type { Match } from '../types'

function buildICS(matches: Match[]): string {
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//MatchPulse//EN'
  ]
  for (const m of matches) {
    const start = new Date(m.utcDate).toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z'
    const end = new Date(+new Date(m.utcDate) + 2 * 60 * 60 * 1000)
      .toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z'
    lines.push(
      'BEGIN:VEVENT',
      `UID:${m.id}@matchpulse`,
      `DTSTART:${start}`,
      `DTEND:${end}`,
      `SUMMARY:${m.homeTeam.shortName} vs ${m.awayTeam.shortName}`,
      `DESCRIPTION:${m.competition.name}`,
      `LOCATION:${m.venue ?? ''}`,
      'END:VEVENT'
    )
  }
  lines.push('END:VCALENDAR')
  return lines.join('\r\n')
}

export default function CalendarPage() {
  const [matches, setMatches] = useState<Match[]>([])
  const [favoritesOnly, setFavoritesOnly] = useState(true)
  const [favoriteIds, setFavoriteIds] = useState<Set<number>>(new Set())

  useEffect(() => {
    getUpcomingMatches().then(setMatches).catch(() => setMatches([]))
    getFavorites().then((favs) => setFavoriteIds(new Set(favs.map((f) => f.id))))
  }, [])

  const filtered = favoritesOnly
    ? matches.filter((m) => favoriteIds.has(m.homeTeam.id) || favoriteIds.has(m.awayTeam.id))
    : matches

  const grouped = groupByDate(filtered)

  function handleExport() {
    const ics = buildICS(filtered)
    const blob = new Blob([ics], { type: 'text/calendar' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'matchpulse-fixtures.ics'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="pb-24">
      <Header title="Calendar" subtitle="Your upcoming fixtures" />
      <div className="px-5 mt-2 space-y-4">
        <div className="flex gap-2">
          <button
            onClick={() => setFavoritesOnly(true)}
            className={`flex-1 rounded-xl py-2 text-sm font-medium ${favoritesOnly ? 'bg-floodlight-500 text-ink-900' : 'bg-ink-800 text-mist-400'}`}
          >
            Following
          </button>
          <button
            onClick={() => setFavoritesOnly(false)}
            className={`flex-1 rounded-xl py-2 text-sm font-medium ${!favoritesOnly ? 'bg-floodlight-500 text-ink-900' : 'bg-ink-800 text-mist-400'}`}
          >
            All matches
          </button>
        </div>

        <button
          onClick={handleExport}
          disabled={filtered.length === 0}
          className="w-full rounded-xl border border-ink-600/50 text-sm font-medium text-white py-2.5 disabled:opacity-40"
        >
          Export .ics ({filtered.length})
        </button>

        {Object.entries(grouped).map(([date, dayMatches]) => (
          <section key={date}>
            <h3 className="text-xs uppercase tracking-wide text-mist-500 mb-2">
              {new Date(date).toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}
            </h3>
            <div className="space-y-2.5">
              {dayMatches.map((m) => (
                <MatchCard key={m.id} match={m} />
              ))}
            </div>
          </section>
        ))}

        {filtered.length === 0 && (
          <p className="text-sm text-mist-500 text-center pt-6">
            {favoritesOnly ? 'Follow a team on the Favorites tab to see fixtures here.' : 'No upcoming fixtures loaded.'}
          </p>
        )}
      </div>
    </div>
  )
}

function groupByDate(matches: Match[]): Record<string, Match[]> {
  const sorted = [...matches].sort((a, b) => +new Date(a.utcDate) - +new Date(b.utcDate))
  return sorted.reduce((acc, m) => {
    const day = m.utcDate.slice(0, 10)
    acc[day] = acc[day] ? [...acc[day], m] : [m]
    return acc
  }, {} as Record<string, Match[]>)
}
