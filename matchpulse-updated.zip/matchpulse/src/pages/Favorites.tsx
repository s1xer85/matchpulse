import { useEffect, useState } from 'react'
import Header from '../components/Header'
import { getFavorites, toggleFavorite } from '../lib/db'
import type { FavoriteTeam } from '../types'

// Curated seed list — the free football-data.org tier covers these clubs'
// competitions directly (PL, PD, BL1, SA, FL1, DED, PPL, BSA + CL/WC/EC
// national sides). Add more by editing this list (or wire up the Search
// page to /data/teams.json once you've pulled a bigger team index).
//
// NOTE: team IDs below are football-data.org's own numeric IDs. If a crest
// fails to load or a team's matches never show up, double check its ID at
// https://docs.football-data.org (Teams endpoint) and correct it here —
// a wrong ID just means "no matches match" rather than a crash.
//
// IMPORTANT: only clubs from these competitions will ever have matches
// appear, because scripts/fetch-data.mjs only fetches those competition
// codes: CL, PL, PD, BL1, SA, FL1, DED, PPL, BSA, WC, EC. Clubs from
// leagues outside that list (Saudi Pro League, MLS, Argentine Primera,
// Turkish Süper Lig, etc.) can be listed here but will never show fixtures
// unless you add their competition code to fetch-data.mjs (needs a paid
// football-data.org plan for most of those).
const SUGGESTED: FavoriteTeam[] = [
  // Premier League
  { id: 86, name: 'Real Madrid', crest: 'https://crests.football-data.org/86.png', type: 'club' },
  { id: 81, name: 'FC Barcelona', crest: 'https://crests.football-data.org/81.png', type: 'club' },
  { id: 64, name: 'Liverpool FC', crest: 'https://crests.football-data.org/64.png', type: 'club' },
  { id: 65, name: 'Manchester City', crest: 'https://crests.football-data.org/65.png', type: 'club' },
  { id: 66, name: 'Manchester United', crest: 'https://crests.football-data.org/66.png', type: 'club' },
  { id: 57, name: 'Arsenal FC', crest: 'https://crests.football-data.org/57.png', type: 'club' },
  { id: 61, name: 'Chelsea FC', crest: 'https://crests.football-data.org/61.png', type: 'club' },
  { id: 73, name: 'Tottenham Hotspur', crest: 'https://crests.football-data.org/73.png', type: 'club' },
  { id: 67, name: 'Newcastle United', crest: 'https://crests.football-data.org/67.png', type: 'club' },
  { id: 58, name: 'Aston Villa', crest: 'https://crests.football-data.org/58.png', type: 'club' },
  { id: 397, name: 'Brighton & Hove Albion', crest: 'https://crests.football-data.org/397.png', type: 'club' },
  { id: 563, name: 'West Ham United', crest: 'https://crests.football-data.org/563.png', type: 'club' },
  // La Liga
  { id: 78, name: 'Atlético Madrid', crest: 'https://crests.football-data.org/78.png', type: 'club' },
  { id: 559, name: 'Sevilla FC', crest: 'https://crests.football-data.org/559.png', type: 'club' },
  { id: 90, name: 'Real Betis', crest: 'https://crests.football-data.org/90.png', type: 'club' },
  { id: 92, name: 'Real Sociedad', crest: 'https://crests.football-data.org/92.png', type: 'club' },
  // Bundesliga
  { id: 5, name: 'FC Bayern München', crest: 'https://crests.football-data.org/5.png', type: 'club' },
  { id: 4, name: 'Borussia Dortmund', crest: 'https://crests.football-data.org/4.png', type: 'club' },
  { id: 3, name: 'Bayer Leverkusen', crest: 'https://crests.football-data.org/3.png', type: 'club' },
  { id: 18, name: 'Borussia Mönchengladbach', crest: 'https://crests.football-data.org/18.png', type: 'club' },
  { id: 721, name: 'RB Leipzig', crest: 'https://crests.football-data.org/721.png', type: 'club' },
  // Serie A
  { id: 109, name: 'Juventus FC', crest: 'https://crests.football-data.org/109.png', type: 'club' },
  { id: 98, name: 'AC Milan', crest: 'https://crests.football-data.org/98.png', type: 'club' },
  { id: 108, name: 'Inter Milan', crest: 'https://crests.football-data.org/108.png', type: 'club' },
  { id: 113, name: 'SSC Napoli', crest: 'https://crests.football-data.org/113.png', type: 'club' },
  { id: 100, name: 'AS Roma', crest: 'https://crests.football-data.org/100.png', type: 'club' },
  { id: 110, name: 'SS Lazio', crest: 'https://crests.football-data.org/110.png', type: 'club' },
  // Ligue 1
  { id: 524, name: 'Paris Saint-Germain', crest: 'https://crests.football-data.org/524.png', type: 'club' },
  { id: 516, name: 'Olympique de Marseille', crest: 'https://crests.football-data.org/516.png', type: 'club' },
  // Eredivisie
  { id: 678, name: 'Ajax', crest: 'https://crests.football-data.org/678.png', type: 'club' },
  { id: 675, name: 'PSV Eindhoven', crest: 'https://crests.football-data.org/675.png', type: 'club' },
  // Primeira Liga
  { id: 503, name: 'FC Porto', crest: 'https://crests.football-data.org/503.png', type: 'club' },
  { id: 1903, name: 'SL Benfica', crest: 'https://crests.football-data.org/1903.png', type: 'club' },
  { id: 498, name: 'Sporting CP', crest: 'https://crests.football-data.org/498.png', type: 'club' },
  // Brasileirão Série A
  { id: 1783, name: 'Flamengo', crest: 'https://crests.football-data.org/1783.png', type: 'club' },
  { id: 1769, name: 'Palmeiras', crest: 'https://crests.football-data.org/1769.png', type: 'club' },
  { id: 1837, name: 'Corinthians', crest: 'https://crests.football-data.org/1837.png', type: 'club' },
  { id: 1776, name: 'São Paulo FC', crest: 'https://crests.football-data.org/1776.png', type: 'club' },
  { id: 1770, name: 'Santos FC', crest: 'https://crests.football-data.org/1770.png', type: 'club' },
  { id: 1767, name: 'Grêmio', crest: 'https://crests.football-data.org/1767.png', type: 'club' },
  { id: 1766, name: 'Internacional', crest: 'https://crests.football-data.org/1766.png', type: 'club' },
  { id: 6684, name: 'Cruzeiro', crest: 'https://crests.football-data.org/6684.png', type: 'club' },
  { id: 1765, name: 'Atlético Mineiro', crest: 'https://crests.football-data.org/1765.png', type: 'club' },
  { id: 1779, name: 'Fluminense', crest: 'https://crests.football-data.org/1779.png', type: 'club' },
  { id: 6685, name: 'Vasco da Gama', crest: 'https://crests.football-data.org/6685.png', type: 'club' },
  { id: 1777, name: 'Botafogo', crest: 'https://crests.football-data.org/1777.png', type: 'club' },
  // National teams (Champions League/World Cup/Euros coverage)
  { id: 764, name: 'Brazil', crest: 'https://crests.football-data.org/764.png', type: 'national' },
  { id: 761, name: 'Argentina', crest: 'https://crests.football-data.org/761.png', type: 'national' },
  { id: 759, name: 'Germany', crest: 'https://crests.football-data.org/759.png', type: 'national' },
  { id: 760, name: 'France', crest: 'https://crests.football-data.org/760.png', type: 'national' },
  { id: 770, name: 'England', crest: 'https://crests.football-data.org/770.png', type: 'national' },
  { id: 898, name: 'Spain', crest: 'https://crests.football-data.org/898.png', type: 'national' },
  { id: 765, name: 'Portugal', crest: 'https://crests.football-data.org/765.png', type: 'national' },
  { id: 784, name: 'Italy', crest: 'https://crests.football-data.org/784.png', type: 'national' },
  { id: 773, name: 'Netherlands', crest: 'https://crests.football-data.org/773.png', type: 'national' },
  { id: 799, name: 'Belgium', crest: 'https://crests.football-data.org/799.png', type: 'national' }
]

export default function Favorites() {
  const [favorites, setFavorites] = useState<FavoriteTeam[]>([])

  useEffect(() => {
    getFavorites().then(setFavorites)
  }, [])

  async function handleToggle(team: FavoriteTeam) {
    const next = await toggleFavorite(team)
    setFavorites(next)
  }

  const isFav = (id: number) => favorites.some((f) => f.id === id)

  return (
    <div className="pb-24">
      <Header title="Favorites" subtitle="Follow clubs, national teams & more" />
      <div className="px-5 mt-2 space-y-6">
        {favorites.length > 0 && (
          <section>
            <h2 className="font-display text-sm font-semibold text-mist-300 uppercase tracking-wide mb-3">
              Following ({favorites.length})
            </h2>
            <div className="grid grid-cols-2 gap-2.5">
              {favorites.map((team) => (
                <TeamChip key={team.id} team={team} active onToggle={() => handleToggle(team)} />
              ))}
            </div>
          </section>
        )}

        <section>
          <h2 className="font-display text-sm font-semibold text-mist-300 uppercase tracking-wide mb-3">
            Suggested
          </h2>
          <div className="grid grid-cols-2 gap-2.5">
            {SUGGESTED.filter((t) => !isFav(t.id)).map((team) => (
              <TeamChip key={team.id} team={team} active={false} onToggle={() => handleToggle(team)} />
            ))}
          </div>
        </section>

        {favorites.length === 0 && (
          <p className="text-sm text-mist-500 text-center pt-4">
            Tap a team above to start following them — you'll get reminders and see their matches on Home.
          </p>
        )}
      </div>
    </div>
  )
}

function TeamChip({ team, active, onToggle }: { team: FavoriteTeam; active: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      className={`flex items-center gap-2.5 rounded-2xl border px-3 py-2.5 text-left transition-colors
                  ${active ? 'border-floodlight-500/50 bg-floodlight-500/10' : 'border-ink-600/40 bg-ink-800/60'}`}
    >
      <img src={team.crest} alt="" className="w-8 h-8 rounded-full bg-ink-700 object-contain shrink-0" loading="lazy" />
      <span className="text-sm font-medium text-white truncate">{team.name}</span>
      <span className="ml-auto text-floodlight-400 text-lg">{active ? '\u2713' : '+'}</span>
    </button>
  )
}
