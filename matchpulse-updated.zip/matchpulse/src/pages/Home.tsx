import { useEffect, useMemo, useState, type ReactNode } from 'react'
import Header from '../components/Header'
import MatchCard from '../components/MatchCard'
import CountdownScoreboard from '../components/CountdownScoreboard'
import { getUpcomingMatches, getFinishedMatches, getLastUpdated } from '../lib/api'
import { getFavorites } from '../lib/db'
import type { Match, FavoriteTeam } from '../types'

export default function Home() {
  const [upcoming, setUpcoming] = useState<Match[]>([])
  const [finished, setFinished] = useState<Match[]>([])
  const [favorites, setFavorites] = useState<FavoriteTeam[]>([])
  const [updatedAt, setUpdatedAt] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    async function load() {
      try {
        const [u, f, favs, meta] = await Promise.all([
          getUpcomingMatches(),
          getFinishedMatches(),
          getFavorites(),
          getLastUpdated()
        ])
        if (cancelled) return
        setUpcoming(u)
        setFinished(f)
        setFavorites(favs)
        setUpdatedAt(meta)
      } catch (e) {
        if (!cancelled) setError('Match data isn\u2019t available yet. Run the data sync workflow to populate it.')
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    load()
    return () => {
      cancelled = true
    }
  }, [])

  const favoriteIds = useMemo(() => new Set(favorites.map((f) => f.id)), [favorites])

  const nextMatch = useMemo(() => {
    const followed = upcoming.filter((m) => favoriteIds.has(m.homeTeam.id) || favoriteIds.has(m.awayTeam.id))
    const pool = followed.length ? followed : upcoming
    return [...pool].sort((a, b) => +new Date(a.utcDate) - +new Date(b.utcDate))[0]
  }, [upcoming, favoriteIds])

  const today = new Date().toISOString().slice(0, 10)
  const todayMatches = upcoming.filter((m) => m.utcDate.slice(0, 10) === today)
  const laterFixtures = upcoming
    .filter((m) => m.utcDate.slice(0, 10) !== today)
    .slice(0, 8)
  const recentResults = [...finished]
    .sort((a, b) => +new Date(b.utcDate) - +new Date(a.utcDate))
    .slice(0, 6)

  return (
    <div className="pb-24">
      <Header title="MatchPulse" subtitle={greeting()} />

      <div className="px-5 space-y-8 mt-2">
        {loading && <SkeletonBlock />}

        {error && (
          <div className="rounded-2xl border border-pulse-500/30 bg-pulse-500/10 px-4 py-3 text-sm text-pulse-400">
            {error}
          </div>
        )}

        {!loading && !error && nextMatch && <CountdownScoreboard match={nextMatch} />}

        {!loading && !error && todayMatches.length > 0 && (
          <Section title="Today's matches">
            <div className="space-y-2.5">
              {todayMatches.map((m) => (
                <MatchCard key={m.id} match={m} />
              ))}
            </div>
          </Section>
        )}

        {!loading && !error && laterFixtures.length > 0 && (
          <Section title="Upcoming fixtures">
            <div className="space-y-2.5">
              {laterFixtures.map((m) => (
                <MatchCard key={m.id} match={m} />
              ))}
            </div>
          </Section>
        )}

        {!loading && !error && recentResults.length > 0 && (
          <Section title="Recently finished">
            <div className="space-y-2.5">
              {recentResults.map((m) => (
                <MatchCard key={m.id} match={m} />
              ))}
            </div>
          </Section>
        )}

        {updatedAt && (
          <p className="text-center text-xs text-mist-500">
            Data updated {new Date(updatedAt).toLocaleString(undefined, { hour: 'numeric', minute: '2-digit', month: 'short', day: 'numeric' })}
          </p>
        )}
      </div>
    </div>
  )
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="font-display text-sm font-semibold text-mist-300 uppercase tracking-wide mb-3">{title}</h2>
      {children}
    </section>
  )
}

function greeting() {
  const h = new Date().getHours()
  if (h < 5) return 'Late one — kickoff waits for no one'
  if (h < 12) return 'Good morning'
  if (h < 18) return 'Good afternoon'
  return 'Good evening'
}

function SkeletonBlock() {
  return (
    <div className="space-y-3 animate-pulse">
      <div className="h-40 rounded-3xl bg-ink-800/60" />
      <div className="h-16 rounded-2xl bg-ink-800/60" />
      <div className="h-16 rounded-2xl bg-ink-800/60" />
    </div>
  )
}
