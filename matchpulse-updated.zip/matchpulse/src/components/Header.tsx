export default function Header({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <header className="px-5 pt-6 pb-2 sticky top-0 z-30 glass">
      <h1 className="font-display text-2xl font-semibold text-white">{title}</h1>
      {subtitle && <p className="text-sm text-mist-400 mt-0.5">{subtitle}</p>}
    </header>
  )
}
