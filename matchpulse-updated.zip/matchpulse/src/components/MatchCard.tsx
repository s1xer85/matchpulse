import { Link } from 'react-router-dom'
import type { Match } from '../types'

function StatusPill({ match }: { match: Match }) {
  if (match.status === 'IN_PLAY' || match.status === 'LIVE' || match.status === 'PAUSED') {
    return (
      <span className="flex items-center gap-1 text-xs font-semibold text-floodlight-400">
        <span className="w-1.5 h-1.5 rounded-full bg-floodlight-500 animate-pulse" />
        {match.minute ? `${match.minute}'` : 'LIVE'}
      </span>
    )
  }
  if (match.status === 'FINISHED') {
    return <span className="text-xs font-medium text-mist-500">Full-time</span>
  }
  if (match.status === 'POSTPONED') {
    return <span className="text-xs font-medium text-pulse-400">Postponed</span>
  }
  const time = new Date(match.utcDate).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
  return <span className="text-xs font-medium text-mist-400">{time}</span>
}

export default function MatchCard({ match }: { match: Match }) {
  const hasScore = match.score.home !== null && match.score.away !== null

  return (
    <Link
      to={`/match/${match.id}`}
      className="block rounded-2xl bg-ink-800/70 border border-ink-600/40 px-4 py-3
                 shadow-card hover:border-floodlight-500/40 active:scale-[0.98]
                 transition-all duration-150"
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] uppercase tracking-wide text-mist-500">{match.competition.name}</span>
        <StatusPill match={match} />
      </div>
      <div className="flex items-center justify-between">
        <TeamRow name={match.homeTeam.shortName} crest={match.homeTeam.crest} score={hasScore ? match.score.home : null} />
        <TeamRow name={match.awayTeam.shortName} crest={match.awayTeam.crest} score={hasScore ? match.score.away : null} />
      </div>
    </Link>
  )
}

function TeamRow({ name, crest, score }: { name: string; crest: string; score: number | null }) {
  return (
    <div className="flex items-center gap-2 flex-1 min-w-0">
      <img src={crest} alt="" className="w-6 h-6 rounded-full bg-ink-700 object-contain shrink-0" loading="lazy" />
      <span className="text-sm text-white font-medium truncate">{name}</span>
      {score !== null && <span className="ml-auto font-mono font-semibold text-floodlight-400">{score}</span>}
    </div>
  )
}
