import { useEffect, useState } from 'react'
import type { Match } from '../types'

function getRemaining(target: number) {
  const diff = Math.max(target - Date.now(), 0)
  const days = Math.floor(diff / 86_400_000)
  const hours = Math.floor((diff % 86_400_000) / 3_600_000)
  const minutes = Math.floor((diff % 3_600_000) / 60_000)
  const seconds = Math.floor((diff % 60_000) / 1000)
  return { days, hours, minutes, seconds, done: diff === 0 }
}

function Digit({ value, label }: { value: number; label: string }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div
        className="relative w-14 sm:w-16 rounded-xl bg-ink-800 border border-ink-600/60 py-2
                   text-center font-mono text-2xl sm:text-3xl font-semibold text-floodlight-400
                   shadow-glow tabular-nums"
      >
        {String(value).padStart(2, '0')}
      </div>
      <span className="text-[10px] uppercase tracking-widest text-mist-500">{label}</span>
    </div>
  )
}

export default function CountdownScoreboard({ match }: { match: Match }) {
  const target = new Date(match.utcDate).getTime()
  const [remaining, setRemaining] = useState(() => getRemaining(target))

  useEffect(() => {
    const id = setInterval(() => setRemaining(getRemaining(target)), 1000)
    return () => clearInterval(id)
  }, [target])

  const kickoffLocal = new Date(match.utcDate).toLocaleString(undefined, {
    weekday: 'short',
    hour: 'numeric',
    minute: '2-digit'
  })

  return (
    <div className="rounded-3xl bg-stadium bg-ink-800/60 border border-ink-600/40 p-5 sm:p-6">
      <p className="text-xs uppercase tracking-widest text-floodlight-500 font-semibold mb-3">
        Next up · {match.competition.name}
      </p>
      <div className="flex items-center justify-between mb-5">
        <TeamMini name={match.homeTeam.shortName} crest={match.homeTeam.crest} />
        <span className="font-display text-mist-500 text-sm">vs</span>
        <TeamMini name={match.awayTeam.shortName} crest={match.awayTeam.crest} align="right" />
      </div>
      <div className="flex justify-center gap-2 sm:gap-3">
        <Digit value={remaining.days} label="days" />
        <Digit value={remaining.hours} label="hrs" />
        <Digit value={remaining.minutes} label="min" />
        <Digit value={remaining.seconds} label="sec" />
      </div>
      <p className="text-center text-xs text-mist-500 mt-4">Kickoff {kickoffLocal} your time</p>
    </div>
  )
}

function TeamMini({ name, crest, align = 'left' }: { name: string; crest: string; align?: 'left' | 'right' }) {
  return (
    <div className={`flex items-center gap-2 ${align === 'right' ? 'flex-row-reverse' : ''}`}>
      <img src={crest} alt="" className="w-9 h-9 rounded-full bg-ink-700 object-contain" loading="lazy" />
      <span className="font-display font-semibold text-white text-sm sm:text-base">{name}</span>
    </div>
  )
}
