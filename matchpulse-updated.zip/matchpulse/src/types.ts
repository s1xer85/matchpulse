export type MatchStatus = 'SCHEDULED' | 'LIVE' | 'IN_PLAY' | 'PAUSED' | 'FINISHED' | 'POSTPONED'

export interface Team {
  id: number
  name: string
  shortName: string
  crest: string
}

export interface Competition {
  id: number
  name: string
  code: string
  emblem: string
}

export interface Score {
  home: number | null
  away: number | null
}

export interface Match {
  id: number
  utcDate: string // ISO 8601, always UTC — convert to local at render time
  status: MatchStatus
  minute?: number | null
  competition: Competition
  homeTeam: Team
  awayTeam: Team
  score: Score
  venue?: string | null
}

export type ReminderOffset =
  | 'week_1' | 'day_3' | 'day_1' | 'hour_12' | 'hour_6' | 'hour_3'
  | 'hour_1' | 'min_30' | 'min_15' | 'min_5' | 'kickoff'

export interface ReminderEvent {
  offset: ReminderOffset
  enabled: boolean
}

export const REMINDER_LABELS: Record<ReminderOffset, string> = {
  week_1: '1 week before',
  day_3: '3 days before',
  day_1: '1 day before',
  hour_12: '12 hours before',
  hour_6: '6 hours before',
  hour_3: '3 hours before',
  hour_1: '1 hour before',
  min_30: '30 minutes before',
  min_15: '15 minutes before',
  min_5: '5 minutes before',
  kickoff: 'At kickoff'
}

export const REMINDER_MINUTES: Record<ReminderOffset, number> = {
  week_1: 7 * 24 * 60,
  day_3: 3 * 24 * 60,
  day_1: 24 * 60,
  hour_12: 12 * 60,
  hour_6: 6 * 60,
  hour_3: 3 * 60,
  hour_1: 60,
  min_30: 30,
  min_15: 15,
  min_5: 5,
  kickoff: 0
}

export interface FavoriteTeam {
  id: number
  name: string
  crest: string
  type: 'club' | 'national'
}

export interface NotificationPrefs {
  reminders: ReminderOffset[]
  events: {
    goals: boolean
    halfTime: boolean
    fullTime: boolean
    redCard: boolean
    lineupReleased: boolean
  }
}

export const DEFAULT_NOTIFICATION_PREFS: NotificationPrefs = {
  reminders: ['hour_12', 'hour_6', 'hour_3', 'hour_1'],
  events: {
    goals: true,
    halfTime: false,
    fullTime: true,
    redCard: true,
    lineupReleased: true
  }
}
