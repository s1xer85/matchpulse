import type { Match } from '../types'

// Data files are static JSON snapshots refreshed on a schedule by
// .github/workflows/update-data.yml (see scripts/fetch-data.mjs).
// This is what makes the app deployable to plain GitHub Pages with
// zero server and zero exposed API key.

const DATA_BASE = `${import.meta.env.BASE_URL}data`

async function loadJSON<T>(file: string): Promise<T> {
  const res = await fetch(`${DATA_BASE}/${file}?t=${Date.now()}`)
  if (!res.ok) throw new Error(`Failed to load ${file}: ${res.status}`)
  return res.json()
}

export async function getUpcomingMatches(): Promise<Match[]> {
  return loadJSON<Match[]>('upcoming.json')
}

export async function getTodayMatches(): Promise<Match[]> {
  const all = await getUpcomingMatches()
  const today = new Date().toISOString().slice(0, 10)
  return all.filter((m) => m.utcDate.slice(0, 10) === today)
}

export async function getFinishedMatches(): Promise<Match[]> {
  return loadJSON<Match[]>('finished.json')
}

export async function getMatchById(id: number): Promise<Match | undefined> {
  const [upcoming, finished] = await Promise.all([getUpcomingMatches(), getFinishedMatches()])
  return [...upcoming, ...finished].find((m) => m.id === id)
}

export async function getLastUpdated(): Promise<string | null> {
  try {
    const meta = await loadJSON<{ updatedAt: string }>('meta.json')
    return meta.updatedAt
  } catch {
    return null
  }
}
