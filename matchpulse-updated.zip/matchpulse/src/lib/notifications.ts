import type { Match, ReminderOffset } from '../types'
import { REMINDER_MINUTES } from '../types'
import { markScheduled, wasScheduled } from './db'

// NOTE ON LIMITATIONS (read this before extending):
// GitHub Pages serves static files only — there is no server to hold a
// connection open or send Web Push while the app is closed. So v1 schedules
// reminders using setTimeout for the current browser session, and re-checks
// on every app open/foreground so reminders "catch up" if a timer was missed
// while the tab was closed. This covers "app open or installed & pinned"
// usage well. For true background push (app fully closed), you'd add a
// small server or Firebase Cloud Messaging — see README "Upgrading to push".

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (!('Notification' in window)) return 'denied'
  if (Notification.permission === 'default') {
    return Notification.requestPermission()
  }
  return Notification.permission
}

function fireNotification(title: string, body: string) {
  if (Notification.permission !== 'granted') return
  navigator.serviceWorker?.getRegistration().then((reg) => {
    if (reg) {
      reg.showNotification(title, {
        body,
        icon: `${import.meta.env.BASE_URL}icons/icon-192.png`,
        badge: `${import.meta.env.BASE_URL}icons/icon-192.png`
      })
    } else {
      new Notification(title, { body })
    }
  })
}

const activeTimers = new Set<number>()

export async function scheduleReminders(
  matches: Match[],
  followedTeamIds: Set<number>,
  offsets: ReminderOffset[]
) {
  if (Notification.permission !== 'granted') return

  const relevant = matches.filter(
    (m) => followedTeamIds.has(m.homeTeam.id) || followedTeamIds.has(m.awayTeam.id)
  )

  for (const match of relevant) {
    const kickoff = new Date(match.utcDate).getTime()

    for (const offset of offsets) {
      const fireAt = kickoff - REMINDER_MINUTES[offset] * 60_000
      const msUntilFire = fireAt - Date.now()
      const key = `${match.id}:${offset}`

      if (msUntilFire < -5 * 60_000) continue // long past, skip
      if (await wasScheduled(match.id, offset)) continue

      const label =
        offset === 'kickoff'
          ? 'kicks off now'
          : `kicks off in ${REMINDER_MINUTES[offset] >= 60 ? Math.round(REMINDER_MINUTES[offset] / 60) + 'h' : REMINDER_MINUTES[offset] + 'm'}`

      const delay = Math.max(msUntilFire, 0)
      // Cap setTimeout scheduling to ~24h ahead per session; longer-range
      // reminders get re-evaluated the next time the app is opened.
      if (delay > 24 * 60 * 60 * 1000) continue

      const timerId = window.setTimeout(async () => {
        fireNotification(
          `${match.homeTeam.shortName} vs ${match.awayTeam.shortName}`,
          `${match.competition.name} ${label}`
        )
        await markScheduled(match.id, offset)
        activeTimers.delete(timerId)
      }, delay)

      activeTimers.add(timerId)
      void key
    }
  }
}

export function clearAllTimers() {
  for (const id of activeTimers) clearTimeout(id)
  activeTimers.clear()
}
