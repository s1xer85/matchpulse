import { get, set, del, keys } from 'idb-keyval'
import type { FavoriteTeam, NotificationPrefs } from '../types'
import { DEFAULT_NOTIFICATION_PREFS } from '../types'

const FAVORITES_KEY = 'matchpulse:favorites'
const PREFS_KEY = 'matchpulse:notification-prefs'
const SCHEDULED_KEY_PREFIX = 'matchpulse:scheduled:'

export async function getFavorites(): Promise<FavoriteTeam[]> {
  return (await get(FAVORITES_KEY)) ?? []
}

export async function toggleFavorite(team: FavoriteTeam): Promise<FavoriteTeam[]> {
  const current = await getFavorites()
  const exists = current.some((t) => t.id === team.id)
  const next = exists ? current.filter((t) => t.id !== team.id) : [...current, team]
  await set(FAVORITES_KEY, next)
  return next
}

export async function isFavorite(teamId: number): Promise<boolean> {
  const current = await getFavorites()
  return current.some((t) => t.id === teamId)
}

export async function getNotificationPrefs(): Promise<NotificationPrefs> {
  return (await get(PREFS_KEY)) ?? DEFAULT_NOTIFICATION_PREFS
}

export async function setNotificationPrefs(prefs: NotificationPrefs): Promise<void> {
  await set(PREFS_KEY, prefs)
}

// Track which (matchId, offset) reminders have already been scheduled/fired
// this session, so we don't double-notify.
export async function markScheduled(matchId: number, offset: string): Promise<void> {
  await set(`${SCHEDULED_KEY_PREFIX}${matchId}:${offset}`, true)
}

export async function wasScheduled(matchId: number, offset: string): Promise<boolean> {
  return (await get(`${SCHEDULED_KEY_PREFIX}${matchId}:${offset}`)) === true
}

export async function clearOldSchedules(): Promise<void> {
  const all = await keys()
  const stale = all.filter(
    (k) => typeof k === 'string' && k.startsWith(SCHEDULED_KEY_PREFIX)
  )
  // Keep last 500 entries max to avoid unbounded growth
  if (stale.length > 500) {
    for (const k of stale.slice(0, stale.length - 500)) await del(k)
  }
}
