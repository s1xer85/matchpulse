// Pulls upcoming & recent fixtures from football-data.org and writes static
// JSON snapshots into public/data/. Run locally with FOOTBALL_DATA_TOKEN set,
// or automatically via .github/workflows/update-data.yml on a schedule.
//
// Free-tier competitions (permanently free per football-data.org's policy):
// Champions League, Premier League, La Liga, Bundesliga, Serie A, Ligue 1,
// Eredivisie, Primeira Liga, Championship, Brazilian Serie A, World Cup, Euros.

import fs from 'node:fs/promises'
import path from 'node:path'

const TOKEN = process.env.FOOTBALL_DATA_TOKEN
const OUT_DIR = path.resolve('public/data')
const BASE = 'https://api.football-data.org/v4'

// Add/remove competition codes here. See:
// https://docs.football-data.org/general/v4/competitions.html
const COMPETITIONS = ['CL', 'PL', 'PD', 'BL1', 'SA', 'FL1', 'DED', 'PPL', 'BSA', 'WC', 'EC']

if (!TOKEN) {
  console.error(
    '\nFOOTBALL_DATA_TOKEN is not set.\n' +
    'Get a free key at https://www.football-data.org/client/register\n' +
    'then run: FOOTBALL_DATA_TOKEN=xxxx npm run fetch-data\n'
  )
  process.exit(1)
}

async function fetchJSON(url) {
  const res = await fetch(url, { headers: { 'X-Auth-Token': TOKEN } })
  if (!res.ok) {
    throw new Error(`${url} -> ${res.status} ${await res.text()}`)
  }
  return res.json()
}

function normalizeMatch(m) {
  return {
    id: m.id,
    utcDate: m.utcDate,
    status: m.status,
    minute: m.minute ?? null,
    competition: {
      id: m.competition.id,
      name: m.competition.name,
      code: m.competition.code,
      emblem: m.competition.emblem
    },
    homeTeam: {
      id: m.homeTeam.id,
      name: m.homeTeam.name,
      shortName: m.homeTeam.shortName ?? m.homeTeam.name,
      crest: m.homeTeam.crest
    },
    awayTeam: {
      id: m.awayTeam.id,
      name: m.awayTeam.name,
      shortName: m.awayTeam.shortName ?? m.awayTeam.name,
      crest: m.awayTeam.crest
    },
    score: {
      home: m.score?.fullTime?.home ?? null,
      away: m.score?.fullTime?.away ?? null
    },
    venue: m.venue ?? null
  }
}

async function main() {
  await fs.mkdir(OUT_DIR, { recursive: true })

  const dateFrom = new Date()
  const upcomingTo = new Date(Date.now() + 21 * 24 * 60 * 60 * 1000)
  const finishedFrom = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)

  const fmt = (d) => d.toISOString().slice(0, 10)

  let upcoming = []
  let finished = []
  const results = []

  console.log(`Token present: ${TOKEN ? `yes (${TOKEN.length} chars)` : 'NO'}`)
  console.log(`Fetching ${COMPETITIONS.length} competitions: ${COMPETITIONS.join(', ')}\n`)

  // football-data.org rate limit on the free tier is low (10 req/min) —
  // fetch sequentially with a short delay to stay well under it.
  for (const code of COMPETITIONS) {
    let gotUpcoming = 0
    let gotFinished = 0
    let failReason = null
    try {
      const scheduled = await fetchJSON(
        `${BASE}/competitions/${code}/matches?dateFrom=${fmt(dateFrom)}&dateTo=${fmt(upcomingTo)}`
      )
      const normalized = (scheduled.matches ?? []).map(normalizeMatch)
      upcoming.push(...normalized)
      gotUpcoming = normalized.length

      await sleep(6500)

      const past = await fetchJSON(
        `${BASE}/competitions/${code}/matches?dateFrom=${fmt(finishedFrom)}&dateTo=${fmt(dateFrom)}&status=FINISHED`
      )
      const normalizedPast = (past.matches ?? []).map(normalizeMatch)
      finished.push(...normalizedPast)
      gotFinished = normalizedPast.length

      await sleep(6500)
    } catch (err) {
      failReason = err.message
      console.warn(`✗ ${code} failed: ${err.message}`)
    }
    results.push({ code, gotUpcoming, gotFinished, failReason })
  }

  await fs.writeFile(path.join(OUT_DIR, 'upcoming.json'), JSON.stringify(upcoming, null, 2))
  await fs.writeFile(path.join(OUT_DIR, 'finished.json'), JSON.stringify(finished, null, 2))
  await fs.writeFile(
    path.join(OUT_DIR, 'meta.json'),
    JSON.stringify({ updatedAt: new Date().toISOString() }, null, 2)
  )

  console.log('\n--- Summary ---')
  for (const r of results) {
    if (r.failReason) {
      console.log(`${r.code}: FAILED — ${r.failReason}`)
    } else {
      console.log(`${r.code}: ${r.gotUpcoming} upcoming, ${r.gotFinished} finished`)
    }
  }
  console.log(`\nWrote ${upcoming.length} upcoming and ${finished.length} finished matches total.`)

  const allFailed = results.every((r) => r.failReason)
  if (allFailed) {
    console.error(
      '\nEvery competition failed. This almost always means FOOTBALL_DATA_TOKEN is missing, ' +
      'invalid, or the request is being rejected before it even reaches your quota (401/403). ' +
      'Double check the secret value at football-data.org > My Account.'
    )
  }
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms))
}

main().catch((err) => {
  console.error(err)
  process.exit(1)
})
